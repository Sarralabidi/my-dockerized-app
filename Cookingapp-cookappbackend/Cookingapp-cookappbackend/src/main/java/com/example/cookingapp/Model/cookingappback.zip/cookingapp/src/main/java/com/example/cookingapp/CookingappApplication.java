package com.example.cookingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookingappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CookingappApplication.class, args);
	}

}
